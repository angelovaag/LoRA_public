disp('3rd problem');
s=1;
c=[0 0 0 -1 -1]';
a=sparse([-2 0 0 1 0;...
    0 1 0 0 2;...
    0 0 1 3 2]);
b=[4 12 18]';
ctype=['S','S','S']';
lb=[0,0,0,0,0]'; ub=[];
vartype=['C','C','C','C','C']';
param.msglev=3;
lpsolver=2;
[xmin,fmin,status,extra]=glpkmex(s,c,a,b,ctype,lb,ub,vartype,param,lpsolver)
