/* glplpx6d.c (integer optimization routine) */

/* (reserved for copyright notice) */

#include "glplib.h"
#include "glplpx.h"

int lpx_intopt(LPX *mip)
{     insist(mip == mip);
      fault("lpx_intopt: not implemented yet");
      return 0;
}

/* eof */
